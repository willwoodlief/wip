-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 30, 2017 at 03:23 PM
-- Server version: 5.5.55-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `blank`
--

-- --------------------------------------------------------

--
-- Table structure for table `email`
--
-- Creation: Apr 30, 2017 at 03:10 PM
--

DROP TABLE IF EXISTS `email`;
CREATE TABLE IF NOT EXISTS `email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `website_name` varchar(100) NOT NULL,
  `smtp_server` varchar(100) NOT NULL,
  `smtp_port` int(10) NOT NULL,
  `email_login` varchar(150) NOT NULL,
  `email_pass` varchar(100) NOT NULL,
  `from_name` varchar(100) NOT NULL,
  `from_email` varchar(150) NOT NULL,
  `transport` varchar(255) NOT NULL,
  `verify_url` varchar(255) NOT NULL,
  `email_act` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `email`
--

INSERT INTO `email` (`id`, `website_name`, `smtp_server`, `smtp_port`, `email_login`, `email_pass`, `from_name`, `from_email`, `transport`, `verify_url`, `email_act`) VALUES
(1, 'emailsrvr.com', 'smtp.emailsrvr.com', 587, 'info@gokabam.com', 'apple-daily-8', 'HT Testing', 'info@gokabam.com', 'tls', 'http://localhost/ht/', 0);

-- --------------------------------------------------------

--
-- Table structure for table `keys`
--
-- Creation: Apr 30, 2017 at 03:10 PM
--

DROP TABLE IF EXISTS `keys`;
CREATE TABLE IF NOT EXISTS `keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stripe_ts` varchar(255) NOT NULL,
  `stripe_tp` varchar(255) NOT NULL,
  `stripe_ls` varchar(255) NOT NULL,
  `stripe_lp` varchar(255) NOT NULL,
  `recap_pub` varchar(100) NOT NULL,
  `recap_pri` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--
-- Creation: Apr 30, 2017 at 03:10 PM
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page` varchar(100) NOT NULL,
  `private` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=61 ;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `page`, `private`) VALUES
(1, 'index.php', 0),
(2, 'z_us_root.php', 1),
(3, 'users/account.php', 1),
(4, 'users/admin.php', 1),
(5, 'users/admin_page.php', 1),
(6, 'users/admin_pages.php', 1),
(7, 'users/admin_permission.php', 1),
(8, 'users/admin_permissions.php', 1),
(9, 'users/admin_user.php', 1),
(10, 'users/admin_users.php', 1),
(11, 'users/edit_profile.php', 1),
(12, 'users/email_settings.php', 1),
(13, 'users/email_test.php', 1),
(14, 'users/forgot_password.php', 0),
(15, 'users/forgot_password_reset.php', 0),
(16, 'users/index.php', 0),
(17, 'users/init.php', 1),
(18, 'users/join.php', 0),
(19, 'users/joinThankYou.php', 0),
(20, 'users/login.php', 0),
(21, 'users/logout.php', 0),
(22, 'users/profile.php', 1),
(23, 'users/times.php', 1),
(24, 'users/user_settings.php', 1),
(25, 'users/verify.php', 0),
(26, 'users/verify_resend.php', 0),
(27, 'users/view_all_users.php', 1),
(28, 'usersc/empty.php', 1),
(29, 'info.php', 1),
(35, 'users/private_init.php', 1),
(41, 'pages/index.php', 1),
(45, 'pages/save_image.php', 1),
(46, 'users/private_init.example.php', 1),
(47, 'pages/ping_alive.php', 1),
(49, 'pages/help.php', 1),
(50, 'phinx.php', 1),
(51, 'users/init.cli.php', 1),
(55, 'pages/home.php', 1),
(56, 'pages/about_us.php', 1),
(57, 'pages/carriers.php', 1),
(58, 'pages/contact_us.php', 1),
(59, 'pages/partner_program.php', 0),
(60, 'pages/solutions.php', 1);

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--
-- Creation: Apr 30, 2017 at 03:10 PM
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`) VALUES
(1, 'User'),
(2, 'Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `permission_page_matches`
--
-- Creation: Apr 30, 2017 at 03:10 PM
--

DROP TABLE IF EXISTS `permission_page_matches`;
CREATE TABLE IF NOT EXISTS `permission_page_matches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(15) NOT NULL,
  `page_id` int(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `permission_page_matches`
--

INSERT INTO `permission_page_matches` (`id`, `permission_id`, `page_id`) VALUES
(2, 2, 27),
(3, 1, 24),
(4, 1, 22),
(5, 2, 13),
(6, 2, 12),
(7, 1, 11),
(8, 2, 10),
(9, 2, 9),
(10, 2, 8),
(11, 2, 7),
(12, 2, 6),
(13, 2, 5),
(14, 2, 4),
(15, 1, 3),
(16, 2, 29),
(19, 2, 31),
(21, 2, 36),
(25, 2, 38),
(28, 2, 39),
(29, 2, 40),
(30, 2, 42),
(31, 2, 41),
(35, 2, 43),
(39, 2, 44),
(42, 2, 45),
(45, 2, 47),
(51, 1, 49),
(54, 2, 53),
(55, 2, 54),
(56, 1, 55),
(57, 2, 55),
(58, 1, 56),
(59, 2, 56),
(60, 1, 60),
(61, 2, 60),
(62, 1, 57),
(63, 2, 57),
(64, 1, 58),
(65, 2, 58),
(66, 2, 49);

-- --------------------------------------------------------

--
-- Table structure for table `phinxlog`
--
-- Creation: Apr 30, 2017 at 03:10 PM
--

DROP TABLE IF EXISTS `phinxlog`;
CREATE TABLE IF NOT EXISTS `phinxlog` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `end_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `breakpoint` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `phinxlog`
--

INSERT INTO `phinxlog` (`version`, `migration_name`, `start_time`, `end_time`, `breakpoint`) VALUES
(20161013070810, 'AddConfigFolderWatch', '2016-10-13 02:51:09', '2016-10-13 02:51:09', 0),
(20161013070908, 'AddFileWatching', '2016-10-15 11:54:23', '2016-10-15 11:54:23', 0),
(20161015174702, 'AddRgxSettings', '2016-10-15 12:49:14', '2016-10-15 12:49:14', 0),
(20161015180251, 'AddSideSettings', '2016-10-15 13:03:48', '2016-10-15 13:03:48', 0),
(20161019082256, 'AddUpConfigLocation', '2016-10-19 03:29:44', '2016-10-19 03:29:44', 0),
(20161021120637, 'AddPagePermsUploadJson', '2016-10-21 07:24:33', '2016-10-21 07:24:33', 0),
(20161021133256, 'AddExtensionToJobs', '2016-10-21 08:34:07', '2016-10-21 08:34:07', 0),
(20161028072520, 'Tags', '2016-10-28 04:17:15', '2016-10-28 04:17:16', 0),
(20161109150505, 'AddJobFields', '2016-11-09 10:09:18', '2016-11-09 10:09:20', 0),
(20161109182141, 'RenameTagJobTable', '2016-11-09 12:24:47', '2016-11-09 12:24:47', 0),
(20161110214456, 'AddPermsForTestJson', '2016-11-10 15:59:58', '2016-11-10 15:59:58', 0);

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--
-- Creation: Apr 30, 2017 at 03:10 PM
--

DROP TABLE IF EXISTS `profiles`;
CREATE TABLE IF NOT EXISTS `profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `bio` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `user_id`, `bio`) VALUES
(1, 1, '<h1>This is the Admin''s bio.</h1>'),
(2, 2, 'This is your bio'),
(18, 18, 'This is your bio');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--
-- Creation: Apr 30, 2017 at 03:10 PM
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `recaptcha` int(1) NOT NULL DEFAULT '0',
  `force_ssl` int(1) NOT NULL,
  `login_type` varchar(20) NOT NULL,
  `css_sample` int(1) NOT NULL,
  `us_css1` varchar(255) NOT NULL,
  `us_css2` varchar(255) NOT NULL,
  `us_css3` varchar(255) NOT NULL,
  `css1` varchar(255) NOT NULL,
  `css2` varchar(255) NOT NULL,
  `css3` varchar(255) NOT NULL,
  `site_name` varchar(100) NOT NULL,
  `language` varchar(255) NOT NULL,
  `track_guest` int(1) NOT NULL,
  `site_offline` int(1) NOT NULL,
  `force_pr` int(1) NOT NULL,
  `reserved1` varchar(100) NOT NULL,
  `reserverd2` varchar(100) NOT NULL,
  `custom1` varchar(100) NOT NULL,
  `custom2` varchar(100) NOT NULL,
  `custom3` varchar(100) NOT NULL,
  `website_url` varchar(255) DEFAULT NULL,
  `s3_bucket_name` varchar(255) DEFAULT NULL,
  `view_timeout_seconds` int(11) NOT NULL DEFAULT '900',
  `sns_arn` varchar(255) DEFAULT NULL,
  `folder_watch` varchar(255) DEFAULT NULL,
  `folder_watch_filter_rgx` varchar(255) DEFAULT NULL,
  `folder_watch_group_rgx` varchar(255) DEFAULT NULL,
  `folder_watch_side_a_match` varchar(255) DEFAULT NULL,
  `user_profile_config` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `recaptcha`, `force_ssl`, `login_type`, `css_sample`, `us_css1`, `us_css2`, `us_css3`, `css1`, `css2`, `css3`, `site_name`, `language`, `track_guest`, `site_offline`, `force_pr`, `reserved1`, `reserverd2`, `custom1`, `custom2`, `custom3`, `website_url`, `s3_bucket_name`, `view_timeout_seconds`, `sns_arn`, `folder_watch`, `folder_watch_filter_rgx`, `folder_watch_group_rgx`, `folder_watch_side_a_match`, `user_profile_config`) VALUES
(1, 1, 0, '', 1, '../users/css/color_schemes/dark.css', '../users/css/bootstrap.css', '../users/css/us-admin.css', '', '', '', 'Testing Shell', 'en', 0, 0, 0, '', '', '', '', '', 'http://localhost/blank', 'texdevelopers-local-ht', 1000, 'arn:aws:sns:us-west-2:963635107936:gokobam-alerts', '', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Creation: Apr 30, 2017 at 03:10 PM
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(155) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `permissions` int(11) NOT NULL,
  `logins` int(100) NOT NULL,
  `account_owner` tinyint(4) NOT NULL DEFAULT '0',
  `account_id` int(11) NOT NULL DEFAULT '0',
  `company` varchar(255) NOT NULL,
  `stripe_cust_id` varchar(255) NOT NULL,
  `billing_phone` varchar(20) NOT NULL,
  `billing_srt1` varchar(255) NOT NULL,
  `billing_srt2` varchar(255) NOT NULL,
  `billing_city` varchar(255) NOT NULL,
  `billing_state` varchar(255) NOT NULL,
  `billing_zip_code` varchar(255) NOT NULL,
  `join_date` datetime NOT NULL,
  `last_login` datetime NOT NULL,
  `email_verified` tinyint(4) NOT NULL DEFAULT '0',
  `vericode` varchar(15) NOT NULL,
  `title` varchar(100) NOT NULL,
  `active` int(1) NOT NULL,
  `custom1` varchar(255) NOT NULL,
  `custom2` varchar(255) NOT NULL,
  `custom3` varchar(255) NOT NULL,
  `custom4` varchar(255) NOT NULL,
  `custom5` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `EMAIL` (`email`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `username`, `password`, `fname`, `lname`, `permissions`, `logins`, `account_owner`, `account_id`, `company`, `stripe_cust_id`, `billing_phone`, `billing_srt1`, `billing_srt2`, `billing_city`, `billing_state`, `billing_zip_code`, `join_date`, `last_login`, `email_verified`, `vericode`, `title`, `active`, `custom1`, `custom2`, `custom3`, `custom4`, `custom5`) VALUES
(1, 'willwoodlief+ht+admin@gmail.com', 'admin', '$2y$12$9R4u4lVraHZeJJ6YVJxO4e43./LZQLwC3VVlS1BvSN1IsZJDOooFK', 'Admin', 'Woodlief', 1, 38, 1, 0, 'UserSpice', '', '', '', '', '', '', '', '2016-01-01 00:00:00', '2017-04-30 15:04:17', 1, '322418', '', 0, '', '', '', '', ''),
(2, 'noreply@userspice.com', 'user', '$2y$12$HZa0/d7evKvuHO8I3U8Ff.pOjJqsGTZqlX8qURratzP./EvWetbkK', 'user', 'user', 1, 0, 1, 0, 'none', '', '', '', '', '', '', '', '2016-01-02 00:00:00', '2016-01-02 00:00:00', 1, '970748', '', 1, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users_online`
--
-- Creation: Apr 30, 2017 at 03:10 PM
--

DROP TABLE IF EXISTS `users_online`;
CREATE TABLE IF NOT EXISTS `users_online` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) NOT NULL,
  `timestamp` varchar(15) NOT NULL,
  `user_id` int(10) NOT NULL,
  `session` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users_session`
--
-- Creation: Apr 30, 2017 at 03:10 PM
--

DROP TABLE IF EXISTS `users_session`;
CREATE TABLE IF NOT EXISTS `users_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `uagent` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=71 ;

--
-- Dumping data for table `users_session`
--

INSERT INTO `users_session` (`id`, `user_id`, `hash`, `uagent`) VALUES
(38, 1, 'e5c284103ce354831561e3b447d1758976c799922d7e20743e9f8c290dfe078f', 'Mozilla (Windows NT 6.1; Win64; x64) AppleWebKit (KHTML, like Gecko) Chrome Safari'),
(59, 1, 'db3fc920f05cb03ac2e6427d81b25eff0b7e5c1bdd989d0ce2c47755711d0b00', 'Mozilla (X11; Ubuntu; Linux x86_64; rv:48.0) Gecko Firefox'),
(62, 1, '47cc3646d596389ddd65e7c19097778471de5eb7dfdb51efcd1bf2135cd93e9c', 'Mozilla (X11; Ubuntu; Linux x86_64; rv:49.0) Gecko Firefox'),
(63, 1, '4b2d836627fc45669d32cf93dde803125d90b5f2f6d4c2adcb199bc04b498cea', 'Mozilla (X11; Ubuntu; Linux x86_64; rv:49.0) Gecko Firefox'),
(65, 1, '238ec4c84d5cb6b61909d81beeec113cd80b74e0376419688d675dd35e2c6c83', 'Mozilla (X11; Ubuntu; Linux x86_64; rv:49.0) Gecko Firefox'),
(66, 1, '7410066f470dbbac8d5ad107bdaab539b3e6206da45061be9efdd4a6be7520ac', 'Mozilla (X11; Ubuntu; Linux x86_64; rv:49.0) Gecko Firefox'),
(68, 1, '45025c68a9f2b17c16489a395b8d5fd8ff9bacf412ceeb030bb85ec7072491b3', 'Mozilla (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko Firefox'),
(70, 1, '0154ce9a9d3d1f0837fbea3ea4e3783feb88039d2ac846eb77b8607a7953aefe', 'Mozilla (X11; Linux x86_64) AppleWebKit (KHTML, like Gecko) Chrome Safari');

-- --------------------------------------------------------

--
-- Table structure for table `user_permission_matches`
--
-- Creation: Apr 30, 2017 at 03:10 PM
--

DROP TABLE IF EXISTS `user_permission_matches`;
CREATE TABLE IF NOT EXISTS `user_permission_matches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=112 ;

--
-- Dumping data for table `user_permission_matches`
--

INSERT INTO `user_permission_matches` (`id`, `user_id`, `permission_id`) VALUES
(100, 1, 1),
(101, 1, 2),
(102, 2, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
